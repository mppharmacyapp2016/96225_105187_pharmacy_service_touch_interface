package pl.mefiu.pharmacyapp;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Pattern;
import com.mongodb.client.MongoCollection;

import org.bson.Document;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import roboguice.fragment.RoboFragment;
import roboguice.inject.InjectView;

import static com.mongodb.client.model.Filters.eq;

public class MedicineReceptionFragment extends RoboFragment implements Validator.ValidationListener {

    @InjectView(R.id.fragment_medicine_reception_manufacturer_edit_text)
    private EditText manufacturerEditText;

    @InjectView(R.id.fragment_medicine_reception_name_edit_text)
    private EditText nameEditText;

    @InjectView(R.id.fragment_medicine_reception_type_edit_text)
    private EditText typeEditText;

    @InjectView(R.id.fragment_medicine_reception_dose_edit_text)
    private EditText doseEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]+")
    @InjectView(R.id.fragment_medicine_reception_quantity_edit_text)
    private EditText quantityEditText;

    @InjectView(R.id.fragment_medicine_reception_previous_button)
    private Button previousButton;

    @InjectView(R.id.fragment_medicine_reception_next_button)
    private Button nextButton;

    @InjectView(R.id.fragment_medicine_reception_accept_button)
    private Button acceptButton;

    private OnFragmentInteractionListener mListener;

    private List<Document> documents = new ArrayList<>();

    private int currentDocument;

    private Validator validator;

    public MedicineReceptionFragment() {
    }

    public static MedicineReceptionFragment newInstance(String param1, String param2) {
        MedicineReceptionFragment fragment = new MedicineReceptionFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        validator = new Validator(this);
        validator.setValidationListener(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_medicine_reception, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        acceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validator.validate();
            }
        });
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentDocument < (documents.size() - 1)) {
                    currentDocument++;
                    updateMedicineView();
                }
            }
        });
        previousButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentDocument > 0) {
                    currentDocument--;
                    updateMedicineView();
                }
            }
        });
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    for (Document document : mListener.getMongoDatabase().getCollection("medicines").find()) {
                        documents.add(document);
                    }
                    return null;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        currentDocument = 0;
        updateMedicineView();
    }

    private void updateMedicineView() {
        if (documents.size() == 0) {
            return;
        }
        manufacturerEditText.setText((String) documents.get(currentDocument).get("manufacturer"));
        nameEditText.setText((String) documents.get(currentDocument).get("name"));
        typeEditText.setText((String) documents.get(currentDocument).get("type"));
        doseEditText.setText(String.valueOf(documents.get(currentDocument).get("dose")));
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onValidationSucceeded() {
        if (documents.size() == 0) {
            return;
        }
        Integer quantity = Integer.valueOf(quantityEditText.getText().toString()) + (Integer) documents.get(currentDocument).get("availableQuantity");
        final Document document = new Document();
        document.append("availableQuantity", quantity);
        final MongoCollection<Document> medicines = mListener.getMongoDatabase().getCollection("medicines");
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    medicines.updateOne(eq("_id", documents.get(currentDocument).get("_id")), new Document("$set", document));
                    return null;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        getFragmentManager().popBackStack();
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(getActivity().getApplicationContext());
            if (view instanceof EditText) {
                ((EditText) view).setError(message);
            } else {
                Toast.makeText(getActivity().getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }
        }
    }

}
