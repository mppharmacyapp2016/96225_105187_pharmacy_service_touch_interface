package pl.mefiu.pharmacyapp;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import org.bson.Document;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import roboguice.fragment.RoboFragment;
import roboguice.inject.InjectView;

public class ViewMedicineFragment extends RoboFragment {

    @InjectView(R.id.fragment_view_medicine_manufacturer_edit_text)
    private EditText manufacturerEditText;

    @InjectView(R.id.fragment_view_medicine_name_edit_text)
    private EditText nameEditText;

    @InjectView(R.id.fragment_view_medicine_type_edit_text)
    private EditText typeEditText;

    @InjectView(R.id.fragment_view_medicine_dose_edit_text)
    private EditText doseEditText;

    @InjectView(R.id.fragment_view_medicine_active_substance_edit_text)
    private EditText activeSubstanceEditText;

    @InjectView(R.id.fragment_view_medicine_auxiliary_substances_edit_text)
    private EditText auxiliarySubstancesEditText;

    @InjectView(R.id.fragment_view_medicine_content_edit_text)
    private EditText contentEditText;

    @InjectView(R.id.fragment_view_medicine_can_be_divided_edit_text)
    private EditText canBeDividedEditText;

    @InjectView(R.id.fragment_view_medicine_refund_edit_text)
    private EditText refundEditText;

    @InjectView(R.id.fragment_view_medicine_price_before_refund_edit_text)
    private EditText priceBeforeRefundEditText;

    @InjectView(R.id.fragment_view_medicine_price_after_refund_edit_text)
    private EditText priceAfterRefundEditText;

    @InjectView(R.id.fragment_view_medicine_price_edit_text)
    private EditText priceEditText;

    @InjectView(R.id.fragment_view_medicine_short_description_edit_text)
    private EditText shortDescriptionEditText;

    @InjectView(R.id.fragment_view_medicine_available_quantity_edit_text)
    private EditText availableQuantityEditText;

    @InjectView(R.id.fragment_view_medicine_number_of_packages_sold_edit_text)
    private EditText numberOfPackagesSoldEditText;

    @InjectView(R.id.fragment_view_medicine_number_of_packages_frozen_edit_text)
    private EditText numberOfPackagesFrozenEditText;

    @InjectView(R.id.fragment_view_medicine_discontinued_edit_text)
    private EditText discontinuedStateEditText;

    @InjectView(R.id.fragment_view_medicine_previous_button)
    private Button previousButton;

    @InjectView(R.id.fragment_view_medicine_next_button)
    private Button nextButton;

    private OnFragmentInteractionListener mListener;

    private List<Document> documents = new ArrayList<>();

    private int currentDocument;

    public ViewMedicineFragment() {
    }

    public static ViewMedicineFragment newInstance(String param1, String param2) {
        ViewMedicineFragment fragment = new ViewMedicineFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_view_medicine, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentDocument < (documents.size() - 1)) {
                    currentDocument++;
                    updateMedicineView();
                }
            }
        });
        previousButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentDocument > 0) {
                    currentDocument--;
                    updateMedicineView();
                }
            }
        });
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    for (Document document : mListener.getMongoDatabase().getCollection("medicines").find()) {
                        documents.add(document);
                    }
                    return null;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        currentDocument = 0;
        updateMedicineView();
    }

    private void updateMedicineView() {
        if (documents.size() == 0) {
            return;
        }
        manufacturerEditText.setText((String) documents.get(currentDocument).get("manufacturer"));
        nameEditText.setText((String) documents.get(currentDocument).get("name"));
        typeEditText.setText((String) documents.get(currentDocument).get("type"));
        doseEditText.setText(String.valueOf(documents.get(currentDocument).get("dose")));
        activeSubstanceEditText.setText((String) documents.get(currentDocument).get("activeSubstance"));
        auxiliarySubstancesEditText.setText((String) documents.get(currentDocument).get("auxiliarySubstances"));
        contentEditText.setText(String.valueOf(documents.get(currentDocument).get("content")));
        canBeDividedEditText.setText(String.valueOf(documents.get(currentDocument).get("canBeDivided")));
        refundEditText.setText(String.valueOf(documents.get(currentDocument).get("refund")));
        priceBeforeRefundEditText.setText(String.valueOf(documents.get(currentDocument).get("priceBeforeRefund")));
        priceAfterRefundEditText.setText(String.valueOf(documents.get(currentDocument).get("priceAfterRefund")));
        priceEditText.setText(String.valueOf(documents.get(currentDocument).get("price")));
        shortDescriptionEditText.setText((String) documents.get(currentDocument).get("shortDescription"));
        availableQuantityEditText.setText(String.valueOf(documents.get(currentDocument).get("availableQuantity")));
        numberOfPackagesSoldEditText.setText(String.valueOf(documents.get(currentDocument).get("numberOfPackagesSold")));
        numberOfPackagesFrozenEditText.setText(String.valueOf(documents.get(currentDocument).get("numberOfPackagesFrozen")));
        discontinuedStateEditText.setText(String.valueOf(documents.get(currentDocument).get("discontinued")));
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

}
