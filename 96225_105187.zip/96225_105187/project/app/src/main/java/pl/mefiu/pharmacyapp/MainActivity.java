package pl.mefiu.pharmacyapp;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import org.bson.Document;

import java.math.BigInteger;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.ByteOrder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutionException;

import roboguice.activity.RoboFragmentActivity;

import static com.mongodb.client.model.Filters.eq;

public class MainActivity extends RoboFragmentActivity implements OnFragmentInteractionListener {

    private MongoClient mongoClient;

    private MongoDatabase mongoDatabase;

    private Document employee;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (savedInstanceState != null) {
            return;
        }
        employee = null;
        mongoClient = new MongoClient("192.168.1.24", 27017);
        mongoDatabase = mongoClient.getDatabase("pharmacy-db");
        final MongoCollection<Document> employees = mongoDatabase.getCollection("employees");
        final MongoCollection<Document> pharmacyBusinessCards = mongoDatabase.getCollection("pbc");
        Long countEmployees = null;
        Long countPharmacyBusinessCards = null;
        try {
            countEmployees = new AsyncTask<Void, Void, Long>() {
                @Override
                protected Long doInBackground(Void... params) {
                    return employees.count();
                }
            }.execute().get();
            countPharmacyBusinessCards = new AsyncTask<Void, Void, Long>() {
                @Override
                protected Long doInBackground(Void... params) {
                    return pharmacyBusinessCards.count();
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        assert countEmployees != null;
        assert countPharmacyBusinessCards != null;
        if (countEmployees == 0) {
            changeFragment(R.id.activity_main_root_container_frame_layout, new RegisterFragment(), null, null, null, null, false);
        } else if (countPharmacyBusinessCards == 0) {
            changeFragment(R.id.activity_main_root_container_frame_layout, new AddPharmacyBusinessCardFragment(), null, null, null, null, false);
        } else {
            changeFragment(R.id.activity_main_root_container_frame_layout, new LoginFragment(), null, null, null, null, false);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        final MongoCollection<Document> employees = getMongoDatabase().getCollection("employees");
        final MongoCollection<Document> loggingEvents = getMongoDatabase().getCollection("liloev");
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    employees.updateOne(eq("username", getEmployee().get("username")), new Document("$set", new Document("loggedIn", false)));
                    Document document = new Document().append("info", "[LOGGING_OUT] " + getEmployee().get("username") + " / " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()) + " / " + wifiIpAddress(getApplicationContext()));
                    loggingEvents.insertOne(document);
                    return null;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        finish();
        System.exit(0);
    }

    @Override
    public boolean changeFragment(Integer idContainerView, Fragment fragment, Integer enter, Integer exit, Integer popEnter, Integer popExit, boolean addToBackStack) {
        if (idContainerView != null) {
            if (fragment != null) {
                if ((enter != null) && (exit != null) && (popEnter == null) && (popExit == null)) {
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.setCustomAnimations(enter, exit);
                    fragmentTransaction.replace(idContainerView, fragment);
                    if (addToBackStack) {
                        fragmentTransaction.addToBackStack("");
                    }
                    fragmentTransaction.commit();
                    return true;
                } else if ((enter != null) && (exit != null) && (popEnter != null) && (popExit != null)) {
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.setCustomAnimations(enter, exit, popEnter, popExit);
                    fragmentTransaction.replace(idContainerView, fragment);
                    if (addToBackStack) {
                        fragmentTransaction.addToBackStack("");
                    }
                    fragmentTransaction.commit();
                    return true;
                } else if ((enter == null) && (exit == null) && (popEnter == null) && (popExit == null)) {
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(idContainerView, fragment);
                    if (addToBackStack) {
                        fragmentTransaction.addToBackStack("");
                    }
                    fragmentTransaction.commit();
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    @Override
    public MongoClient getMongoClient() {
        return mongoClient;
    }

    @Override
    public MongoDatabase getMongoDatabase() {
        return mongoDatabase;
    }

    @Override
    public Document getEmployee() {
        return employee;
    }

    @Override
    public Document setEmployee() {
        return employee;
    }

    @Override
    public void ownerCreated() {
        changeFragment(R.id.activity_main_root_container_frame_layout, new AddPharmacyBusinessCardFragment(), null, null, null, null, false);
    }

    @Override
    public void pharmacyBusinessCardCreated() {
        changeFragment(R.id.activity_main_root_container_frame_layout, new LoginFragment(), null, null, null, null, false);
    }

    @Override
    public void loggedIn(Document employee) {
        this.employee = employee;
        changeFragment(R.id.activity_main_root_container_frame_layout, new MenuFragment(), null, null, null, null, false);
    }

    @Override
    public String wifiIpAddress(Context context) {
        WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        int ipAddress = wifiManager.getConnectionInfo().getIpAddress();
        if (ByteOrder.nativeOrder().equals(ByteOrder.LITTLE_ENDIAN)) {
            ipAddress = Integer.reverseBytes(ipAddress);
        }
        byte[] ipByteArray = BigInteger.valueOf(ipAddress).toByteArray();
        String ipAddressString;
        try {
            ipAddressString = InetAddress.getByAddress(ipByteArray).getHostAddress();
        } catch (UnknownHostException ex) {
            ipAddressString = null;
        }
        return ipAddressString;
    }

}
