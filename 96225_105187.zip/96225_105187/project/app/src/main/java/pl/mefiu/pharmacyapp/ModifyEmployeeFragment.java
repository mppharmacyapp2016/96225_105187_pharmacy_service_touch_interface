package pl.mefiu.pharmacyapp;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.Email;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Pattern;
import com.mongodb.client.MongoCollection;

import org.bson.Document;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import roboguice.fragment.RoboFragment;
import roboguice.inject.InjectView;

import static com.mongodb.client.model.Filters.eq;

public class ModifyEmployeeFragment extends RoboFragment implements Validator.ValidationListener {

    @NotEmpty
    @Pattern(regex = "[a-zA-Z]+")
    @InjectView(R.id.fragment_modify_employee_first_name_edit_text)
    private EditText firstNameEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z]+")
    @InjectView(R.id.fragment_modify_employee_second_name_edit_text)
    private EditText secondNameEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z0-9]+")
    @InjectView(R.id.fragment_modify_employee_username_edit_text)
    private EditText usernameEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z0-9]+")
    @InjectView(R.id.fragment_modify_employee_password_edit_text)
    private EditText passwordEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]{11}")
    @InjectView(R.id.fragment_modify_employee_personal_identification_number_edit_text)
    private EditText personalIdentificationNumberEditText;

    @NotEmpty
    @Email
    @InjectView(R.id.fragment_modify_employee_email_edit_text)
    private EditText emailEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]{9}")
    @InjectView(R.id.fragment_modify_employee_phone_number_edit_text)
    private EditText phoneNumberEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z]+")
    @InjectView(R.id.fragment_modify_employee_country_edit_text)
    private EditText countryEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z]+")
    @InjectView(R.id.fragment_modify_employee_state_edit_text)
    private EditText stateEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z]+")
    @InjectView(R.id.fragment_modify_employee_city_edit_text)
    private EditText cityEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]{5}")
    @InjectView(R.id.fragment_modify_employee_postal_code_edit_text)
    private EditText postalCodeEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z0-9]+")
    @InjectView(R.id.fragment_modify_employee_street_edit_text)
    private EditText streetEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]+")
    @InjectView(R.id.fragment_modify_employee_home_number_edit_text)
    private EditText homeNumberEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]{4}")
    @InjectView(R.id.fragment_modify_employee_salary_edit_text)
    private EditText salaryEditText;

    @InjectView(R.id.fragment_modify_employee_previous_button)
    private Button previousButton;

    @InjectView(R.id.fragment_modify_employee_next_button)
    private Button nextButton;

    @InjectView(R.id.fragment_modify_employee_modify_button)
    private Button modifyButton;

    private OnFragmentInteractionListener mListener;

    private Validator validator;

    private List<Document> documents = new ArrayList<>();

    private int currentDocument;

    public ModifyEmployeeFragment() {
    }

    public static ModifyEmployeeFragment newInstance(String param1, String param2) {
        ModifyEmployeeFragment fragment = new ModifyEmployeeFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        validator = new Validator(this);
        validator.setValidationListener(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_modify_employee, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        modifyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validator.validate();
            }
        });
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentDocument < (documents.size() - 1)) {
                    currentDocument++;
                    updateEmployeeView();
                }
            }
        });
        previousButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentDocument > 0) {
                    currentDocument--;
                    updateEmployeeView();
                }
            }
        });
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    for (Document document : mListener.getMongoDatabase().getCollection("employees").find()) {
                        documents.add(document);
                    }
                    return null;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        currentDocument = 0;
        updateEmployeeView();
    }

    private void updateEmployeeView() {
        if (documents.size() == 0) {
            return;
        }
        firstNameEditText.setText((String) documents.get(currentDocument).get("firstName"));
        secondNameEditText.setText((String) documents.get(currentDocument).get("secondName"));
        usernameEditText.setText((String) documents.get(currentDocument).get("username"));
        passwordEditText.setText((String) documents.get(currentDocument).get("password"));
        personalIdentificationNumberEditText.setText((String) documents.get(currentDocument).get("personalIdentificationNumber"));
        emailEditText.setText((String) documents.get(currentDocument).get("email"));
        phoneNumberEditText.setText((String) documents.get(currentDocument).get("phoneNumber"));
        countryEditText.setText((String) documents.get(currentDocument).get("country"));
        stateEditText.setText((String) documents.get(currentDocument).get("state"));
        cityEditText.setText((String) documents.get(currentDocument).get("city"));
        postalCodeEditText.setText((String) documents.get(currentDocument).get("postalCode"));
        streetEditText.setText((String) documents.get(currentDocument).get("street"));
        homeNumberEditText.setText((String) documents.get(currentDocument).get("homeNumber"));
        salaryEditText.setText((String) documents.get(currentDocument).get("salary"));
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onValidationSucceeded() {
        if (documents.size() == 0) {
            return;
        }
        final String firstName = firstNameEditText.getText().toString();
        String secondName = secondNameEditText.getText().toString();
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        final String personalIdentificationNumber = personalIdentificationNumberEditText.getText().toString();
        String email = emailEditText.getText().toString();
        String phoneNumber = phoneNumberEditText.getText().toString();
        String country = countryEditText.getText().toString();
        String state = stateEditText.getText().toString();
        String city = cityEditText.getText().toString();
        String postalCode = postalCodeEditText.getText().toString();
        String street = streetEditText.getText().toString();
        String homeNumber = homeNumberEditText.getText().toString();
        String salary = salaryEditText.getText().toString();
        final Document document = new Document();
        document.append("_id", documents.get(currentDocument).get("_id"));
        document.append("fullName", firstName + " " + secondName);
        document.append("firstName", firstName);
        document.append("secondName", secondName);
        document.append("username", username);
        document.append("password", password);
        document.append("personalIdentificationNumber", personalIdentificationNumber);
        document.append("email", email);
        document.append("phoneNumber", phoneNumber);
        document.append("country", country);
        document.append("state", state);
        document.append("city", city);
        document.append("postalCode", postalCode);
        document.append("street", street);
        document.append("homeNumber", homeNumber);
        document.append("salary", salary);
        document.append("active", documents.get(currentDocument).get("active"));
        document.append("loggedIn", documents.get(currentDocument).get("loggedIn"));
        document.append("position", documents.get(currentDocument).get("position"));
        document.append("numberOfShoppingCarts", documents.get(currentDocument).get("numberOfShoppingCarts"));
        final MongoCollection<Document> employees = mListener.getMongoDatabase().getCollection("employees");
        final boolean[] flag = new boolean[1];
        flag[0] = false;
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    long count = employees.count(new Document("personalIdentificationNumber", personalIdentificationNumber));
                    if ((count == 0) || (count == 1)) {
                        employees.updateOne(eq("_id", document.get("_id")), new Document("$set", document));
                        flag[0] = true;
                    }
                    return null;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        if (!flag[0]) {
            Toast.makeText(getActivity(), "Employee with PIN: " + personalIdentificationNumber + " already exists!", Toast.LENGTH_LONG).show();
        } else {
            getFragmentManager().popBackStack();
        }
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(getActivity().getApplicationContext());
            if (view instanceof EditText) {
                ((EditText) view).setError(message);
            } else {
                Toast.makeText(getActivity().getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }
        }
    }

}
