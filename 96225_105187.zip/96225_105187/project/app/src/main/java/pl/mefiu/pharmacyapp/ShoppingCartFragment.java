package pl.mefiu.pharmacyapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.itextpdf.text.Anchor;
import com.itextpdf.text.Chapter;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Section;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Pattern;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;

import org.bson.Document;
import org.bson.types.ObjectId;
import org.w3c.dom.Text;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutionException;

import roboguice.fragment.RoboFragment;
import roboguice.inject.InjectView;

import static com.mongodb.client.model.Filters.eq;

public class ShoppingCartFragment extends RoboFragment implements Validator.ValidationListener {

    private static Font catFont = new Font(Font.FontFamily.TIMES_ROMAN, 18, Font.BOLD);

    private static Font subFont = new Font(Font.FontFamily.TIMES_ROMAN, 16, Font.BOLD);

    @InjectView(R.id.fragment_shopping_cart_medicine_name_auto_complete_text_view)
    private AutoCompleteTextView medicineNameAutoCompleteTextView;

    @InjectView(R.id.fragment_shopping_cart_total_amount_text_view)
    private TextView totalAmountTextView;

    @NotEmpty
    @Pattern(regex = "[0-9]+")
    @InjectView(R.id.fragment_shopping_cart_item_quantity_edit_text)
    private EditText quantityEditText;

    @InjectView(R.id.fragment_shopping_cart_add_button)
    private Button addButton;

    @InjectView(R.id.fragment_shopping_cart_finish_button)
    private Button finishButton;

    @InjectView(R.id.fragment_shopping_cart_dynamic_items_linear_layout)
    private LinearLayout dynamicItemsLinearLayout;

    private OnFragmentInteractionListener mListener;

    private Validator validator;

    private MongoCollection<Document> medicinesCol;

    private MongoCollection<Document> shoppingCartsCol;

    private MongoCollection<Document> shoppingCartItemsCol;

    private List<Button> deleteButtons = new ArrayList<>();

    private List<String> addedMedicines = new ArrayList<>();

    private List<TextView> addedMedicinesTitles = new ArrayList<>();

    public ShoppingCartFragment() {
    }

    public static ShoppingCartFragment newInstance(String param1, String param2) {
        ShoppingCartFragment fragment = new ShoppingCartFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        validator = new Validator(this);
        validator.setValidationListener(this);
        medicinesCol = mListener.getMongoDatabase().getCollection("medicines");
        shoppingCartsCol = mListener.getMongoDatabase().getCollection("shoppingCarts");
        shoppingCartItemsCol = mListener.getMongoDatabase().getCollection("shoppingCartItems");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_shopping_cart, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validator.validate();
            }
        });
        finishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishTransaction();
            }
        });
        final List<String> medicineNames = new ArrayList<>();
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    for (Document doc : medicinesCol.find()) {
                        if (doc.get("discontinued").equals(false)) {
                            medicineNames.add(doc.getString("name") + "," + doc.get("type") + "," + doc.get("dose"));
                        }
                    }
                    return null;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        final String[] medicineNamesArr = new String[medicineNames.size()];
        int i = 0;
        for (String medicineName : medicineNames) {
            medicineNamesArr[i] = medicineName;
            i++;
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_dropdown_item_1line, medicineNamesArr);
        medicineNameAutoCompleteTextView.setAdapter(adapter);
    }

    private void addMedicine() {
        if (addedMedicines.contains(medicineNameAutoCompleteTextView.getText().toString())) {
            Toast.makeText(getActivity(), "You already have " + medicineNameAutoCompleteTextView.getText().toString() + " in shopping cart! Remove first!", Toast.LENGTH_LONG).show();
            return;
        }
        final Integer quantity = Integer.valueOf(quantityEditText.getText().toString());
        final String name = medicineNameAutoCompleteTextView.getText().toString().split(",")[0];
        final String type = medicineNameAutoCompleteTextView.getText().toString().split(",")[1];
        final Integer dose = Integer.valueOf(medicineNameAutoCompleteTextView.getText().toString().split(",")[2]);
        if (quantity == 0) {
            Toast.makeText(getActivity(), "Qty must be greater than 0!", Toast.LENGTH_LONG).show();
        } else {
            final List<Document> medicine = new ArrayList<>();
            try {
                new AsyncTask<Void, Void, Void>() {
                    @Override
                    protected Void doInBackground(Void... params) {
                        for (Document doc : medicinesCol.find()) {
                            final String _name = (String) doc.get("name");
                            final String _type = (String) doc.get("type");
                            final Integer _dose = (Integer) doc.get("dose");
                            if ((_name.equals(name)) && (_type.equals(type)) && (_dose.equals(dose))) {
                                medicine.add(doc);
                                break;
                            }
                        }
                        return null;
                    }
                }.execute().get();
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
            if (medicine.size() == 1) {
                if (medicine.get(0).getInteger("availableQuantity") >= quantity) {
                    try {
                        new AsyncTask<Void, Void, Void>() {
                            @Override
                            protected Void doInBackground(Void... params) {
                                medicinesCol.updateOne(new Document("name", name), new Document("$set", new Document("availableQuantity", medicine.get(0).getInteger("availableQuantity") - quantity)));
                                return null;
                            }
                        }.execute().get();
                    } catch (InterruptedException | ExecutionException e) {
                        e.printStackTrace();
                    }
                    final LinearLayout ll = new LinearLayout(getActivity());
                    ll.setOrientation(LinearLayout.VERTICAL);
                    ll.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    final TextView tv = new TextView(getActivity());
                    tv.setText(medicine.get(0).get("name") + "," + medicine.get(0).get("type") + "," + medicine.get(0).get("dose") + "," + String.format("%.2f", medicine.get(0).getDouble("priceAfterRefund")) + "," + String.format("%.2f", medicine.get(0).getDouble("priceAfterRefund") * quantity) + "," + quantity);
                    tv.setGravity(View.TEXT_ALIGNMENT_CENTER);
                    tv.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    ll.addView(tv);
                    addedMedicinesTitles.add(tv);
                    LinearLayout ll2 = new LinearLayout(getActivity());
                    ll2.setOrientation(LinearLayout.HORIZONTAL);
                    ll2.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    final TextView tv2 = new TextView(getActivity());
                    tv2.setText(quantity.toString());
                    tv2.setGravity(View.TEXT_ALIGNMENT_CENTER);
                    tv2.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    ll2.addView(tv2);
                    final CheckBox checkBox = new CheckBox(getActivity());
                    checkBox.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    checkBox.setClickable(true);
                    checkBox.setChecked(true);
                    checkBox.setText("Refund?");
                    checkBox.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            refundMedicine(tv, ((CheckBox) v).isChecked(), medicine, quantity);
                        }
                    });
                    ll2.addView(checkBox);
                    Button btn3 = new Button(getActivity());
                    btn3.setText("D");
                    btn3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            removeMedicine(ll, medicine, quantity, checkBox.isChecked());
                        }
                    });
                    deleteButtons.add(btn3);
                    btn3.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    ll2.addView(btn3);
                    Button btn4 = new Button(getActivity());
                    btn4.setText("I");
                    btn4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            infoMedicine(name);
                        }
                    });
                    btn4.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    ll2.addView(btn4);
                    ll.addView(ll2);
                    dynamicItemsLinearLayout.addView(ll);
                    Double newAmount = Double.valueOf(totalAmountTextView.getText().toString().split(": ")[1]);
                    newAmount += medicine.get(0).getDouble("priceAfterRefund") * quantity;
                    totalAmountTextView.setText(String.format("TOTAL [PLN]: %.2f", newAmount));
                    quantityEditText.setText(quantity.toString());
                    addedMedicines.add(medicineNameAutoCompleteTextView.getText().toString());
                } else {
                    Toast.makeText(getActivity(), "There is not enough medicine! Quantity: " + quantity + ", but available quantity: " + medicine.get(0).getInteger("availableQuantity").toString(), Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(getActivity(), "No such medicine! Don't modify proposals!", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void removeMedicine(final LinearLayout ll, final List<Document> medicine, Integer quantity, boolean checked) {
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    medicinesCol.updateOne(new Document("name", medicine.get(0).getString("name")), new Document("$set", new Document("availableQuantity", medicine.get(0).getInteger("availableQuantity"))));
                    return null;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        Double newAmount = Double.valueOf(totalAmountTextView.getText().toString().split(": ")[1]);
        if (checked) {
            newAmount -= medicine.get(0).getDouble("priceAfterRefund") * quantity;
            totalAmountTextView.setText(String.format("TOTAL [PLN]: %.2f", newAmount));
        } else {
            newAmount -= medicine.get(0).getDouble("priceBeforeRefund") * quantity;
            totalAmountTextView.setText(String.format("TOTAL [PLN]: %.2f", newAmount));
        }
        ll.setVisibility(View.GONE);
        addedMedicines.remove(medicine.get(0).get("name") + "," + medicine.get(0).get("type") + "," + medicine.get(0).get("dose"));
    }

    private void infoMedicine(final String name) {
        final List<Document> medicine = new ArrayList<>();
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    for (Document doc : medicinesCol.find()) {
                        final String _name = (String) doc.get("name");
                        if (_name.equals(name)) {
                            medicine.add(doc);
                            break;
                        }
                    }
                    return null;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        String msg = "";
        msg += "manufacturer: " + medicine.get(0).get("manufacturer") + "\n";
        msg += "name: " + medicine.get(0).get("name") + "\n";
        msg += "type: " + medicine.get(0).get("type") + "\n";
        msg += "dose: " + medicine.get(0).get("dose") + "\n";
        msg += "activeSubstance: " + medicine.get(0).get("activeSubstance") + "\n";
        msg += "auxiliarySubstances: " + medicine.get(0).get("auxiliarySubstances") + "\n";
        msg += "content: " + medicine.get(0).get("content") + "\n";
        msg += "canBeDivided: " + medicine.get(0).get("canBeDivided") + "\n";
        msg += "refund: " + medicine.get(0).get("refund") + "\n";
        msg += "priceBeforeRefund: " + medicine.get(0).get("priceBeforeRefund") + "\n";
        msg += "priceAfterRefund: " + medicine.get(0).get("priceAfterRefund") + "\n";
        msg += "price: " + medicine.get(0).get("price") + "\n";
        msg += "shortDescription: " + medicine.get(0).get("shortDescription") + "\n";
        msg += "availableQuantity: " + medicine.get(0).get("availableQuantity") + "\n";
        msg += "numberOfPackagesSold: " + medicine.get(0).get("numberOfPackagesSold") + "\n";
        msg += "numberOfPackagesFrozen: " + medicine.get(0).get("numberOfPackagesFrozen") + "\n";
        msg += "discontinued: " + medicine.get(0).get("discontinued") + "\n";
        AlertDialog alertDialog = new AlertDialog.Builder(getActivity()).create();
        alertDialog.setTitle("Medicine info");
        alertDialog.setMessage(msg);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    private void refundMedicine(TextView tv, boolean checked, List<Document> medicine, Integer quantity) {
        if (checked) {
            double priceAfterRefund = medicine.get(0).getDouble("priceAfterRefund") * quantity;
            double priceBeforeRefund = medicine.get(0).getDouble("priceBeforeRefund") * quantity;
            double diff = priceBeforeRefund - priceAfterRefund;
            Double newAmount = Double.valueOf(totalAmountTextView.getText().toString().split(": ")[1]);
            newAmount -= diff;
            totalAmountTextView.setText(String.format("TOTAL [PLN]: %.2f", newAmount));
            tv.setText(medicine.get(0).get("name") + "," + medicine.get(0).get("type") + "," + medicine.get(0).get("dose") + "," + String.format("%.2f", medicine.get(0).getDouble("priceAfterRefund")) + "," + String.format("%.2f", medicine.get(0).getDouble("priceAfterRefund") * quantity));
        } else {
            double priceAfterRefund = medicine.get(0).getDouble("priceAfterRefund") * quantity;
            double priceBeforeRefund = medicine.get(0).getDouble("priceBeforeRefund") * quantity;
            double diff = priceBeforeRefund - priceAfterRefund;
            Double newAmount = Double.valueOf(totalAmountTextView.getText().toString().split(": ")[1]);
            newAmount += diff;
            totalAmountTextView.setText(String.format("TOTAL [PLN]: %.2f", newAmount));
            tv.setText(medicine.get(0).get("name") + "," + medicine.get(0).get("type") + "," + medicine.get(0).get("dose") + "," + String.format("%.2f", medicine.get(0).getDouble("priceBeforeRefund")) + "," + String.format("%.2f", medicine.get(0).getDouble("priceBeforeRefund") * quantity));
        }

    }

    private void finishTransaction() {
        final List<String> str = new ArrayList<>();
        for(TextView tv : addedMedicinesTitles){
            if(((LinearLayout)tv.getParent()).getVisibility() != View.GONE) {
                str.add(tv.getText().toString());
            }
        }
        ObjectId shoppingCartObjectId = null;
        final Double total = Double.valueOf(totalAmountTextView.getText().toString().split(": ")[1]);
        try {
            shoppingCartObjectId = (ObjectId) new AsyncTask<Void, Void, Object>() {
                @Override
                protected Object doInBackground(Void... params) {
                    final Document shoppingCartDocument = new Document();
                    shoppingCartDocument.append("receipt_datetime", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
                    shoppingCartDocument.append("employee_ref", mListener.getEmployee().get("_id"));
                    shoppingCartDocument.append("total_price", total);
                    shoppingCartsCol.insertOne(shoppingCartDocument);
                    for (String s : str) {
                        final Document shoppingCartItemDocument = new Document();
                        shoppingCartItemDocument.append("quantity", s.split(",")[5]);
                        shoppingCartItemDocument.append("medicine_name", s.split(",")[0]);
                        shoppingCartItemDocument.append("shopping_cart_ref", shoppingCartDocument.get("_id"));
                        shoppingCartItemDocument.append("price", s.split(",")[4]);
                        shoppingCartItemsCol.insertOne(shoppingCartItemDocument);
                    }
                    return shoppingCartDocument.get("_id");
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        if (shoppingCartObjectId != null) {
            generateReceipt(shoppingCartObjectId);
            Toast.makeText(getActivity(), "Transaction finished! Receipt generated!", Toast.LENGTH_LONG).show();
        }
        getFragmentManager().popBackStack();
    }

    private void generateReceipt(final ObjectId shoppingCartObjectId) {
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    Document _shoppingCart = shoppingCartsCol.find(eq("_id", shoppingCartObjectId)).first();
                    FindIterable<Document> _shoppingCartItems = shoppingCartItemsCol.find(eq("shopping_cart_ref", shoppingCartObjectId));
                    Document pbc = mListener.getMongoDatabase().getCollection("pbc").find().first();
                    Document owner = mListener.getMongoDatabase().getCollection("employees").find(eq("position", "OWNER")).first();
                    String file = "PharmacyApp_Receipt.pdf";
                    com.itextpdf.text.Document pdfDoc = new com.itextpdf.text.Document();
                    FileOutputStream fileOutputStream = null;
                    try {
                        fileOutputStream = new FileOutputStream(new File("/sdcard/" + file), false);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                    try {
                        PdfWriter.getInstance(pdfDoc, fileOutputStream);
                    } catch (DocumentException e) {
                        e.printStackTrace();
                    }
                    pdfDoc.open();
                    pdfDoc.addTitle("PharmacyApp Receipt");
                    pdfDoc.addSubject("PharmacyApp Receipt");
                    pdfDoc.addKeywords("PharmacyApp, Receipt");
                    pdfDoc.addAuthor("PharmacyApp");
                    pdfDoc.addCreator("PharmacyApp");
                    Anchor anchor = new Anchor("Receipt Details", catFont);
                    anchor.setName("Receipt Details");
                    Chapter catPart = new Chapter(new Paragraph(anchor), 1);
                    Paragraph subPara = new Paragraph("Your shopping cart", subFont);
                    Section subCatPart = catPart.addSection(subPara);
                    subCatPart.add(new Paragraph("Pharmacy name: " + pbc.get("name")));
                    subCatPart.add(new Paragraph("Pharmacy business registration number: " + pbc.get("businessRegistration")));
                    subCatPart.add(new Paragraph("Pharmacy tax id number: " + pbc.get("taxIdentificationNumber")));
                    subCatPart.add(new Paragraph("Pharmacy phone number: " + pbc.get("phoneNumber")));
                    subCatPart.add(new Paragraph("Pharmacy email: " + pbc.get("email")));
                    subCatPart.add(new Paragraph("Owner full name: " + owner.get("fullName")));
                    subCatPart.add(new Paragraph("Owner PIN: " + owner.get("personalIdentificationNumber")));
                    subCatPart.add(new Paragraph("Date: " + _shoppingCart.get("receipt_datetime")));
                    subCatPart.add(new Paragraph("Total cost: " + _shoppingCart.get("total_price")));
                    Paragraph paragraph = new Paragraph();
                    for (int i = 0; i < 2; i++) {
                        paragraph.add(new Paragraph(" "));
                    }
                    subCatPart.add(paragraph);
                    createTable(subCatPart, _shoppingCartItems);
                    try {
                        pdfDoc.add(catPart);
                    } catch (DocumentException e) {
                        e.printStackTrace();
                    }
                    pdfDoc.close();
                    return null;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }

    private void createTable(Section subCatPart, final FindIterable<Document> _shoppingCartItems) {
        final PdfPTable table = new PdfPTable(3);
        PdfPCell c1 = new PdfPCell(new Phrase("Medicine Name"));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c1);
        c1 = new PdfPCell(new Phrase("Quantity"));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c1);
        c1 = new PdfPCell(new Phrase("Price"));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c1);
        table.setHeaderRows(1);
        for (Document document : _shoppingCartItems) {
            table.addCell((String) document.get("medicine_name"));
            table.addCell(String.valueOf(document.get("quantity")));
            table.addCell(String.valueOf(document.get("price")));
        }
        subCatPart.add(table);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        for (Button btn : deleteButtons) {
            btn.performClick();
        }
    }

    @Override
    public void onValidationSucceeded() {
        addMedicine();
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(getActivity().getApplicationContext());
            if (view instanceof EditText) {
                ((EditText) view).setError(message);
            } else {
                Toast.makeText(getActivity().getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }
        }
    }

}
