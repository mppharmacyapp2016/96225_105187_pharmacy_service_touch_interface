package pl.mefiu.pharmacyapp;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.Email;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Pattern;
import com.mongodb.client.MongoCollection;

import org.bson.Document;

import java.util.List;
import java.util.concurrent.ExecutionException;

import roboguice.fragment.RoboFragment;
import roboguice.inject.InjectView;

import static com.mongodb.client.model.Filters.eq;

public class ModifyPharmacyBusinessCardFragment extends RoboFragment implements Validator.ValidationListener {

    @NotEmpty
    @Pattern(regex = "[a-zA-Z]+")
    @InjectView(R.id.fragment_modify_pharmacy_business_card_name_edit_text)
    private EditText nameEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]{9}")
    @InjectView(R.id.fragment_modify_pharmacy_business_card_business_registration_number_edit_text)
    private EditText businessRegistrationNumberEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]{10}")
    @InjectView(R.id.fragment_modify_pharmacy_business_card_tax_identification_number_edit_text)
    private EditText taxIdentificationNumberEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]{9}")
    @InjectView(R.id.fragment_modify_pharmacy_business_card_phone_number_edit_text)
    private EditText phoneNumberEditText;

    @NotEmpty
    @Email
    @InjectView(R.id.fragment_modify_pharmacy_business_card_email_edit_text)
    private EditText emailEditText;

    @InjectView(R.id.fragment_modify_pharmacy_business_card_modify_button)
    private Button modifyButton;

    private OnFragmentInteractionListener mListener;

    private Validator validator;

    public ModifyPharmacyBusinessCardFragment() {
    }

    public static ModifyPharmacyBusinessCardFragment newInstance(String param1, String param2) {
        ModifyPharmacyBusinessCardFragment fragment = new ModifyPharmacyBusinessCardFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        validator = new Validator(this);
        validator.setValidationListener(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_modify_pharmacy_business_card, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        modifyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validator.validate();
            }
        });
        Document pbc = null;
        try {
            pbc = new AsyncTask<Void, Void, Document>() {
                @Override
                protected Document doInBackground(Void... params) {
                    return mListener.getMongoDatabase().getCollection("pbc").find().first();
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        assert pbc != null;
        nameEditText.setText((String) pbc.get("name"));
        businessRegistrationNumberEditText.setText((String) pbc.get("businessRegistration"));
        taxIdentificationNumberEditText.setText((String) pbc.get("taxIdentificationNumber"));
        emailEditText.setText((String) pbc.get("email"));
        phoneNumberEditText.setText((String) pbc.get("phoneNumber"));
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onValidationSucceeded() {
        final String name = nameEditText.getText().toString();
        final Document document = new Document();
        document.append("phoneNumber", phoneNumberEditText.getText().toString());
        document.append("email", emailEditText.getText().toString());
        final MongoCollection<Document> pbcs = mListener.getMongoDatabase().getCollection("pbc");
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    pbcs.updateOne(eq("name", name), new Document("$set", document));
                    return null;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        getFragmentManager().popBackStack();
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(getActivity().getApplicationContext());
            if (view instanceof EditText) {
                ((EditText) view).setError(message);
            } else {
                Toast.makeText(getActivity().getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }
        }
    }

}
