package pl.mefiu.pharmacyapp;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.Email;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Pattern;
import com.mongodb.client.MongoCollection;

import org.bson.Document;

import java.util.List;
import java.util.concurrent.ExecutionException;

import roboguice.fragment.RoboFragment;
import roboguice.inject.InjectView;

public class HireEmployeeFragment extends RoboFragment implements Validator.ValidationListener {

    @NotEmpty
    @Pattern(regex = "[a-zA-Z]+")
    @InjectView(R.id.fragment_hire_employee_first_name_edit_text)
    private EditText firstNameEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z]+")
    @InjectView(R.id.fragment_hire_employee_second_name_edit_text)
    private EditText secondNameEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z0-9]+")
    @InjectView(R.id.fragment_hire_employee_username_edit_text)
    private EditText usernameEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z0-9]+")
    @InjectView(R.id.fragment_hire_employee_password_edit_text)
    private EditText passwordEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]{11}")
    @InjectView(R.id.fragment_hire_employee_personal_identification_number_edit_text)
    private EditText personalIdentificationNumberEditText;

    @NotEmpty
    @Email
    @InjectView(R.id.fragment_hire_employee_email_edit_text)
    private EditText emailEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]{9}")
    @InjectView(R.id.fragment_hire_employee_phone_number_edit_text)
    private EditText phoneNumberEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z]+")
    @InjectView(R.id.fragment_hire_employee_country_edit_text)
    private EditText countryEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z]+")
    @InjectView(R.id.fragment_hire_employee_state_edit_text)
    private EditText stateEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z]+")
    @InjectView(R.id.fragment_hire_employee_city_edit_text)
    private EditText cityEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]{5}")
    @InjectView(R.id.fragment_hire_employee_postal_code_edit_text)
    private EditText postalCodeEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z0-9]+")
    @InjectView(R.id.fragment_hire_employee_street_edit_text)
    private EditText streetEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]+")
    @InjectView(R.id.fragment_hire_employee_home_number_edit_text)
    private EditText homeNumberEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]{4}")
    @InjectView(R.id.fragment_hire_employee_salary_edit_text)
    private EditText salaryEditText;

    @InjectView(R.id.fragment_hire_employee_hire_button)
    private Button hireButton;

    private OnFragmentInteractionListener mListener;

    private Validator validator;

    public HireEmployeeFragment() {
    }

    public static HireEmployeeFragment newInstance(String param1, String param2) {
        HireEmployeeFragment fragment = new HireEmployeeFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        validator = new Validator(this);
        validator.setValidationListener(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_hire_employee, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        hireButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validator.validate();
            }
        });
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onValidationSucceeded() {
        final String firstName = firstNameEditText.getText().toString();
        String secondName = secondNameEditText.getText().toString();
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        final String personalIdentificationNumber = personalIdentificationNumberEditText.getText().toString();
        String email = emailEditText.getText().toString();
        String phoneNumber = phoneNumberEditText.getText().toString();
        String country = countryEditText.getText().toString();
        String state = stateEditText.getText().toString();
        String city = cityEditText.getText().toString();
        String postalCode = postalCodeEditText.getText().toString();
        String street = streetEditText.getText().toString();
        String homeNumber = homeNumberEditText.getText().toString();
        String salary = salaryEditText.getText().toString();
        final Document document = new Document();
        document.append("fullName", firstName + " " + secondName);
        document.append("firstName", firstName);
        document.append("secondName", secondName);
        document.append("username", username);
        document.append("password", password);
        document.append("personalIdentificationNumber", personalIdentificationNumber);
        document.append("email", email);
        document.append("phoneNumber", phoneNumber);
        document.append("country", country);
        document.append("state", state);
        document.append("city", city);
        document.append("postalCode", postalCode);
        document.append("street", street);
        document.append("homeNumber", homeNumber);
        document.append("salary", salary);
        document.append("active", true);
        document.append("loggedIn", false);
        document.append("position", "EMPLOYEE");
        document.append("numberOfShoppingCarts", 0);
        final MongoCollection<Document> employees = mListener.getMongoDatabase().getCollection("employees");
        final boolean[] flag = new boolean[1];
        flag[0] = false;
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    long count = employees.count(new Document("personalIdentificationNumber", personalIdentificationNumber));
                    if (count == 0) {
                        employees.insertOne(document);
                        flag[0] = true;
                    }
                    return null;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        if (flag[0]) {
            getFragmentManager().popBackStack();
        } else {
            Toast.makeText(getActivity(), "Employee with PIN: " + personalIdentificationNumber + " already exists!", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(getActivity().getApplicationContext());
            if (view instanceof EditText) {
                ((EditText) view).setError(message);
            } else {
                Toast.makeText(getActivity().getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }
        }
    }

}
