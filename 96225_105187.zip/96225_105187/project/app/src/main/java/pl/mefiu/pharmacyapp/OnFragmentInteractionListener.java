package pl.mefiu.pharmacyapp;

import android.content.Context;
import android.support.v4.app.Fragment;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;

import org.bson.Document;

public interface OnFragmentInteractionListener {

    boolean changeFragment(Integer idContainerView, Fragment fragment, Integer enter, Integer exit, Integer popEnter, Integer popExit, boolean addToBackStack);

    MongoClient getMongoClient();

    MongoDatabase getMongoDatabase();

    Document getEmployee();

    Document setEmployee();

    void ownerCreated();

    void pharmacyBusinessCardCreated();

    void loggedIn(Document employee);

    String wifiIpAddress(Context context);
}
