package pl.mefiu.pharmacyapp;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Pattern;
import com.mongodb.client.MongoCollection;

import org.bson.Document;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import roboguice.fragment.RoboFragment;
import roboguice.inject.InjectView;

import static com.mongodb.client.model.Filters.eq;

public class ModifyExistingMedicineFragment extends RoboFragment implements Validator.ValidationListener {

    @NotEmpty
    @Pattern(regex = "[a-zA-Z,]+")
    @InjectView(R.id.fragment_modify_existing_medicine_manufacturer_edit_text)
    private EditText manufacturerEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z]+")
    @InjectView(R.id.fragment_modify_existing_medicine_name_edit_text)
    private EditText nameEditText;

    @NotEmpty
    @Pattern(regex = "(PILLS|LIQUID|DROPS|INHALATOR)")
    @InjectView(R.id.fragment_modify_existing_medicine_type_edit_text)
    private EditText typeEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]+")
    @InjectView(R.id.fragment_modify_existing_medicine_dose_edit_text)
    private EditText doseEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z]+")
    @InjectView(R.id.fragment_modify_existing_medicine_active_substance_edit_text)
    private EditText activeSubstanceEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z;]+")
    @InjectView(R.id.fragment_modify_existing_medicine_auxiliary_substances_edit_text)
    private EditText auxiliarySubstancesEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]+")
    @InjectView(R.id.fragment_modify_existing_medicine_content_edit_text)
    private EditText contentEditText;

    @NotEmpty
    @Pattern(regex = "(TRUE|FALSE)")
    @InjectView(R.id.fragment_modify_existing_medicine_can_be_divided_edit_text)
    private EditText canBeDividedEditText;

    @NotEmpty
    @Pattern(regex = "(TRUE|FALSE)")
    @InjectView(R.id.fragment_modify_existing_medicine_refund_edit_text)
    private EditText refundEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]+\\.[0-9]{2}")
    @InjectView(R.id.fragment_modify_existing_medicine_price_before_refund_edit_text)
    private EditText priceBeforeRefundEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]+\\.[0-9]{2}")
    @InjectView(R.id.fragment_modify_existing_medicine_price_after_refund_edit_text)
    private EditText priceAfterRefundEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]+\\.[0-9]{2}")
    @InjectView(R.id.fragment_modify_existing_medicine_price_edit_text)
    private EditText priceEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z\\.,;]+")
    @InjectView(R.id.fragment_modify_existing_medicine_short_description_edit_text)
    private EditText shortDescriptionEditText;

    @InjectView(R.id.fragment_modify_existing_medicine_previous_button)
    private Button previousButton;

    @InjectView(R.id.fragment_modify_existing_medicine_next_button)
    private Button nextButton;

    @InjectView(R.id.fragment_modify_existing_medicine_modify_button)
    private Button modifyButton;

    private OnFragmentInteractionListener mListener;

    private List<Document> documents = new ArrayList<>();

    private int currentDocument;

    private Validator validator;

    public ModifyExistingMedicineFragment() {
    }

    public static ModifyExistingMedicineFragment newInstance(String param1, String param2) {
        ModifyExistingMedicineFragment fragment = new ModifyExistingMedicineFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        validator = new Validator(this);
        validator.setValidationListener(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_modify_existing_medicine, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        modifyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validator.validate();
            }
        });
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentDocument < (documents.size() - 1)) {
                    currentDocument++;
                    updateMedicineView();
                }
            }
        });
        previousButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentDocument > 0) {
                    currentDocument--;
                    updateMedicineView();
                }
            }
        });
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    for (Document document : mListener.getMongoDatabase().getCollection("medicines").find()) {
                        documents.add(document);
                    }
                    return null;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        currentDocument = 0;
        updateMedicineView();
    }

    private void updateMedicineView() {
        if (documents.size() == 0) {
            return;
        }
        manufacturerEditText.setText((String) documents.get(currentDocument).get("manufacturer"));
        nameEditText.setText((String) documents.get(currentDocument).get("name"));
        typeEditText.setText((String) documents.get(currentDocument).get("type"));
        doseEditText.setText(String.valueOf(documents.get(currentDocument).get("dose")));
        activeSubstanceEditText.setText((String) documents.get(currentDocument).get("activeSubstance"));
        auxiliarySubstancesEditText.setText((String) documents.get(currentDocument).get("auxiliarySubstances"));
        contentEditText.setText(String.valueOf(documents.get(currentDocument).get("content")));
        canBeDividedEditText.setText(String.valueOf(documents.get(currentDocument).get("canBeDivided")));
        refundEditText.setText(String.valueOf(documents.get(currentDocument).get("refund")));
        priceBeforeRefundEditText.setText(String.valueOf(documents.get(currentDocument).get("priceBeforeRefund")));
        priceAfterRefundEditText.setText(String.valueOf(documents.get(currentDocument).get("priceAfterRefund")));
        priceEditText.setText(String.valueOf(documents.get(currentDocument).get("price")));
        shortDescriptionEditText.setText((String) documents.get(currentDocument).get("shortDescription"));
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onValidationSucceeded() {
        if (documents.size() == 0) {
            return;
        }
        final String manufacturer = manufacturerEditText.getText().toString();
        final String name = nameEditText.getText().toString();
        final String type = typeEditText.getText().toString();
        final Integer dose = Integer.valueOf(doseEditText.getText().toString());
        final String activeSubstance = activeSubstanceEditText.getText().toString();
        final String auxiliarySubstances = auxiliarySubstancesEditText.getText().toString();
        final Integer content = Integer.valueOf(contentEditText.getText().toString());
        final Boolean canBeDivided = Boolean.valueOf(canBeDividedEditText.getText().toString());
        final Boolean refund = Boolean.valueOf(refundEditText.getText().toString());
        final Double priceBeforeRefund = Double.valueOf(priceBeforeRefundEditText.getText().toString());
        final Double priceAfterRefund = Double.valueOf(priceAfterRefundEditText.getText().toString());
        final Double price = Double.valueOf(priceEditText.getText().toString());
        final String shortDescription = shortDescriptionEditText.getText().toString();
        final Integer availableQuantity = (Integer) documents.get(currentDocument).get("availableQuantity");
        final Integer numberOfPackagesSold = (Integer) documents.get(currentDocument).get("numberOfPackagesSold");
        final Integer numberOfPackagesFrozen = (Integer) documents.get(currentDocument).get("numberOfPackagesFrozen");
        final Boolean discontinued = (Boolean) documents.get(currentDocument).get("discontinued");
        final Document document = new Document();
        document.append("_id", documents.get(currentDocument).get("_id"));
        document.append("manufacturer", manufacturer);
        document.append("name", name);
        document.append("type", type);
        document.append("dose", dose);
        document.append("activeSubstance", activeSubstance);
        document.append("auxiliarySubstances", auxiliarySubstances);
        document.append("content", content);
        document.append("canBeDivided", canBeDivided);
        document.append("refund", refund);
        document.append("priceBeforeRefund", priceBeforeRefund);
        document.append("priceAfterRefund", priceAfterRefund);
        document.append("price", price);
        document.append("shortDescription", shortDescription);
        document.append("availableQuantity", availableQuantity);
        document.append("numberOfPackagesSold", numberOfPackagesSold);
        document.append("numberOfPackagesFrozen", numberOfPackagesFrozen);
        document.append("discontinued", discontinued);
        final MongoCollection<Document> medicines = mListener.getMongoDatabase().getCollection("medicines");
        final boolean[] flag = new boolean[1];
        flag[0] = false;
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    long count = medicines.count(new Document("name", name));
                    if ((count == 0) || (count == 1)) {
                        medicines.updateOne(eq("_id", document.get("_id")), new Document("$set", document));
                        flag[0] = true;
                    }
                    return null;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        if (flag[0]) {
            getFragmentManager().popBackStack();
        } else {
            Toast.makeText(getActivity(), "Medicine with name: " + name + " already exists! Use (name + type + dose) for medicine name", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(getActivity().getApplicationContext());
            if (view instanceof EditText) {
                ((EditText) view).setError(message);
            } else {
                Toast.makeText(getActivity().getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }
        }
    }

}
