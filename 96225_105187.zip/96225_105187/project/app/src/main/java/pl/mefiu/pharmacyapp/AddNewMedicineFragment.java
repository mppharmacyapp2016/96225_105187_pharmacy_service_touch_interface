package pl.mefiu.pharmacyapp;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Pattern;
import com.mongodb.client.MongoCollection;

import org.bson.Document;

import java.util.List;
import java.util.concurrent.ExecutionException;

import roboguice.fragment.RoboFragment;
import roboguice.inject.InjectView;

public class AddNewMedicineFragment extends RoboFragment implements Validator.ValidationListener {

    @NotEmpty
    @Pattern(regex = "[a-zA-Z,]+")
    @InjectView(R.id.fragment_add_new_medicine_manufacturer_edit_text)
    private EditText manufacturerEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z]+")
    @InjectView(R.id.fragment_add_new_medicine_name_edit_text)
    private EditText nameEditText;

    @NotEmpty
    @Pattern(regex = "(PILLS|LIQUID|DROPS|INHALATOR)")
    @InjectView(R.id.fragment_add_new_medicine_type_edit_text)
    private EditText typeEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]+")
    @InjectView(R.id.fragment_add_new_medicine_dose_edit_text)
    private EditText doseEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z]+")
    @InjectView(R.id.fragment_add_new_medicine_active_substance_edit_text)
    private EditText activeSubstanceEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z;]+")
    @InjectView(R.id.fragment_add_new_medicine_auxiliary_substances_edit_text)
    private EditText auxiliarySubstancesEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]+")
    @InjectView(R.id.fragment_add_new_medicine_content_edit_text)
    private EditText contentEditText;

    @NotEmpty
    @Pattern(regex = "(TRUE|FALSE)")
    @InjectView(R.id.fragment_add_new_medicine_can_be_divided_edit_text)
    private EditText canBeDividedEditText;

    @NotEmpty
    @Pattern(regex = "(TRUE|FALSE)")
    @InjectView(R.id.fragment_add_new_medicine_refund_edit_text)
    private EditText refundEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]+\\.[0-9]{2}")
    @InjectView(R.id.fragment_add_new_medicine_price_before_refund_edit_text)
    private EditText priceBeforeRefundEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]+\\.[0-9]{2}")
    @InjectView(R.id.fragment_add_new_medicine_price_after_refund_edit_text)
    private EditText priceAfterRefundEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]+\\.[0-9]{2}")
    @InjectView(R.id.fragment_add_new_medicine_price_edit_text)
    private EditText priceEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z\\.,;]+")
    @InjectView(R.id.fragment_add_new_medicine_short_description_edit_text)
    private EditText shortDescriptionEditText;

    @InjectView(R.id.fragment_add_new_medicine_add_button)
    private Button addButton;

    private OnFragmentInteractionListener mListener;

    private Validator validator;

    public AddNewMedicineFragment() {
    }

    public static AddNewMedicineFragment newInstance(String param1, String param2) {
        AddNewMedicineFragment fragment = new AddNewMedicineFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        validator = new Validator(this);
        validator.setValidationListener(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_add_new_medicine, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validator.validate();
            }
        });
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onValidationSucceeded() {
        final String manufacturer = manufacturerEditText.getText().toString();
        final String name = nameEditText.getText().toString();
        final String type = typeEditText.getText().toString();
        final Integer dose = Integer.valueOf(doseEditText.getText().toString());
        final String activeSubstance = activeSubstanceEditText.getText().toString();
        final String auxiliarySubstances = auxiliarySubstancesEditText.getText().toString();
        final Integer content = Integer.valueOf(contentEditText.getText().toString());
        final Boolean canBeDivided = Boolean.valueOf(canBeDividedEditText.getText().toString());
        final Boolean refund = Boolean.valueOf(refundEditText.getText().toString());
        final Double priceBeforeRefund = Double.valueOf(priceBeforeRefundEditText.getText().toString());
        final Double priceAfterRefund = Double.valueOf(priceAfterRefundEditText.getText().toString());
        final Double price = Double.valueOf(priceEditText.getText().toString());
        final String shortDescription = shortDescriptionEditText.getText().toString();
        final Integer availableQuantity = 0;
        final Integer numberOfPackagesSold = 0;
        final Integer numberOfPackagesFrozen = 0;
        final Boolean discontinued = false;
        final Document document = new Document();
        document.append("manufacturer", manufacturer);
        document.append("name", name);
        document.append("type", type);
        document.append("dose", dose);
        document.append("activeSubstance", activeSubstance);
        document.append("auxiliarySubstances", auxiliarySubstances);
        document.append("content", content);
        document.append("canBeDivided", canBeDivided);
        document.append("refund", refund);
        document.append("priceBeforeRefund", priceBeforeRefund);
        document.append("priceAfterRefund", priceAfterRefund);
        document.append("price", price);
        document.append("shortDescription", shortDescription);
        document.append("availableQuantity", availableQuantity);
        document.append("numberOfPackagesSold", numberOfPackagesSold);
        document.append("numberOfPackagesFrozen", numberOfPackagesFrozen);
        document.append("discontinued", discontinued);
        final MongoCollection<Document> medicines = mListener.getMongoDatabase().getCollection("medicines");
        final boolean[] flag = new boolean[1];
        flag[0] = false;
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    long count = medicines.count(new Document("name", name));
                    if (count == 0) {
                        medicines.insertOne(document);
                        flag[0] = true;
                    }
                    return null;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        if (flag[0]) {
            getFragmentManager().popBackStack();
        } else {
            Toast.makeText(getActivity(), "Medicine with name: " + name + " already exists! Use (name + type + dose) for medicine name", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(getActivity().getApplicationContext());
            if (view instanceof EditText) {
                ((EditText) view).setError(message);
            } else {
                Toast.makeText(getActivity().getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }
        }
    }

}
