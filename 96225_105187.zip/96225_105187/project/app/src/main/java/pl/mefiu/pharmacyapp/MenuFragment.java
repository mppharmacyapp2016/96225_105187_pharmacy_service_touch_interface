package pl.mefiu.pharmacyapp;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.itextpdf.text.Anchor;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chapter;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Section;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.mongodb.client.MongoCollection;

import org.bson.Document;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutionException;

import roboguice.fragment.RoboFragment;
import roboguice.inject.InjectView;

import static com.mongodb.client.model.Filters.eq;

public class MenuFragment extends RoboFragment {

    private static Font catFont = new Font(Font.FontFamily.TIMES_ROMAN, 18, Font.BOLD);

    private static Font redFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.NORMAL, BaseColor.RED);

    private static Font subFont = new Font(Font.FontFamily.TIMES_ROMAN, 16, Font.BOLD);

    private static Font smallBold = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);

    @InjectView(R.id.fragment_menu_option_add_new_employee_text_view)
    private TextView addNewEmployeeTextView;

    @InjectView(R.id.fragment_menu_option_modify_employee_text_view)
    private TextView modifyEmployeeTextView;

    @InjectView(R.id.fragment_menu_option_view_employee_text_view)
    private TextView viewEmployeeTextView;

    @InjectView(R.id.fragment_menu_option_medicine_reception_text_view)
    private TextView medicineReceptionTextView;

    @InjectView(R.id.fragment_menu_option_medicine_reservation_text_view)
    private TextView medicineReservationTextView;

    @InjectView(R.id.fragment_menu_option_discontinue_medicine_sale_text_view)
    private TextView discontinueMedicineTextView;

    @InjectView(R.id.fragment_menu_option_add_new_medicine_text_view)
    private TextView addNewMedicineTextView;

    @InjectView(R.id.fragment_menu_option_modify_medicine_text_view)
    private TextView modifyMedicineTextView;

    @InjectView(R.id.fragment_menu_option_view_medicine_text_view)
    private TextView viewMedicineTextView;

    @InjectView(R.id.fragment_menu_option_modify_pharmacy_business_card_text_view)
    private TextView modifyPharmacyBusinessCardTextView;

    @InjectView(R.id.fragment_menu_option_view_pharmacy_business_card_text_view)
    private TextView viewPharmacyBusinessCardTextView;

    @InjectView(R.id.fragment_menu_option_shopping_cart_text_view)
    private TextView shoppingCartTextView;

    @InjectView(R.id.fragment_menu_option_generate_notifications_report_text_view)
    private TextView generateNotificationsReportTextView;

    @InjectView(R.id.fragment_menu_option_reset_reserved_medicines_text_view)
    private TextView resetReservedMedicinesTextView;

    @InjectView(R.id.fragment_menu_option_exit_text_view)
    private TextView exitTextView;

    private OnFragmentInteractionListener mListener;

    public MenuFragment() {
    }

    public static MenuFragment newInstance(String param1, String param2) {
        MenuFragment fragment = new MenuFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_menu, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        addNewEmployeeTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((OnFragmentInteractionListener) getActivity()).changeFragment(R.id.activity_main_root_container_frame_layout, new HireEmployeeFragment(), R.anim.enter_from_left, R.anim.exit_to_right, R.anim.enter_from_right, R.anim.exit_to_left, true);
            }
        });
        modifyEmployeeTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((OnFragmentInteractionListener) getActivity()).changeFragment(R.id.activity_main_root_container_frame_layout, new ModifyEmployeeFragment(), R.anim.enter_from_left, R.anim.exit_to_right, R.anim.enter_from_right, R.anim.exit_to_left, true);
            }
        });
        viewEmployeeTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((OnFragmentInteractionListener) getActivity()).changeFragment(R.id.activity_main_root_container_frame_layout, new ViewEmployeeFragment(), R.anim.enter_from_left, R.anim.exit_to_right, R.anim.enter_from_right, R.anim.exit_to_left, true);
            }
        });
        medicineReceptionTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((OnFragmentInteractionListener) getActivity()).changeFragment(R.id.activity_main_root_container_frame_layout, new MedicineReceptionFragment(), R.anim.enter_from_left, R.anim.exit_to_right, R.anim.enter_from_right, R.anim.exit_to_left, true);
            }
        });
        medicineReservationTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((OnFragmentInteractionListener) getActivity()).changeFragment(R.id.activity_main_root_container_frame_layout, new MedicineReservationFragment(), R.anim.enter_from_left, R.anim.exit_to_right, R.anim.enter_from_right, R.anim.exit_to_left, true);
            }
        });
        discontinueMedicineTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((OnFragmentInteractionListener) getActivity()).changeFragment(R.id.activity_main_root_container_frame_layout, new DiscontinueMedicineSaleFragment(), R.anim.enter_from_left, R.anim.exit_to_right, R.anim.enter_from_right, R.anim.exit_to_left, true);
            }
        });
        addNewMedicineTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((OnFragmentInteractionListener) getActivity()).changeFragment(R.id.activity_main_root_container_frame_layout, new AddNewMedicineFragment(), R.anim.enter_from_left, R.anim.exit_to_right, R.anim.enter_from_right, R.anim.exit_to_left, true);
            }
        });
        modifyMedicineTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((OnFragmentInteractionListener) getActivity()).changeFragment(R.id.activity_main_root_container_frame_layout, new ModifyExistingMedicineFragment(), R.anim.enter_from_left, R.anim.exit_to_right, R.anim.enter_from_right, R.anim.exit_to_left, true);
            }
        });
        viewMedicineTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((OnFragmentInteractionListener) getActivity()).changeFragment(R.id.activity_main_root_container_frame_layout, new ViewMedicineFragment(), R.anim.enter_from_left, R.anim.exit_to_right, R.anim.enter_from_right, R.anim.exit_to_left, true);
            }
        });
        modifyPharmacyBusinessCardTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((OnFragmentInteractionListener) getActivity()).changeFragment(R.id.activity_main_root_container_frame_layout, new ModifyPharmacyBusinessCardFragment(), R.anim.enter_from_left, R.anim.exit_to_right, R.anim.enter_from_right, R.anim.exit_to_left, true);
            }
        });
        viewPharmacyBusinessCardTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((OnFragmentInteractionListener) getActivity()).changeFragment(R.id.activity_main_root_container_frame_layout, new ViewPharmacyBusinessCardFragment(), R.anim.enter_from_left, R.anim.exit_to_right, R.anim.enter_from_right, R.anim.exit_to_left, true);
            }
        });
        shoppingCartTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((OnFragmentInteractionListener) getActivity()).changeFragment(R.id.activity_main_root_container_frame_layout, new ShoppingCartFragment(), R.anim.enter_from_left, R.anim.exit_to_right, R.anim.enter_from_right, R.anim.exit_to_left, true);
            }
        });
        generateNotificationsReportTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    generateNotificationsReport();
                    Toast.makeText(getActivity(), "Notifications Report Generated. Search for: PharmacyApp_Notifications_Report.pdf", Toast.LENGTH_LONG).show();
                } catch (FileNotFoundException | DocumentException e) {
                    e.printStackTrace();
                    Toast.makeText(getActivity(), "Failed to generate Notifications Report!", Toast.LENGTH_LONG).show();
                }
            }
        });
        resetReservedMedicinesTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    new AsyncTask<Void, Void, Void>() {
                        @Override
                        protected Void doInBackground(Void... params) {
                            for (Document document : mListener.getMongoDatabase().getCollection("medicines").find()) {
                                if ((Integer) document.get("numberOfPackagesFrozen") != 0) {
                                    final Document doc = new Document();
                                    doc.append("numberOfPackagesFrozen", 0);
                                    doc.append("availableQuantity", (Integer) document.get("numberOfPackagesFrozen") + (Integer) document.get("availableQuantity"));
                                    mListener.getMongoDatabase().getCollection("medicines").updateOne(eq("_id", document.get("_id")), new Document("$set", doc));
                                }
                            }
                            return null;
                        }
                    }.execute().get();
                } catch (InterruptedException | ExecutionException e) {
                    e.printStackTrace();
                }
                Toast.makeText(getActivity(), "Reset finished", Toast.LENGTH_LONG).show();
            }
        });
        exitTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final MongoCollection<Document> employees = mListener.getMongoDatabase().getCollection("employees");
                final MongoCollection<Document> loggingEvents = mListener.getMongoDatabase().getCollection("liloev");
                try {
                    new AsyncTask<Void, Void, Void>() {
                        @Override
                        protected Void doInBackground(Void... params) {
                            employees.updateOne(eq("username", mListener.getEmployee().get("username")), new Document("$set", new Document("loggedIn", false)));
                            Document document = new Document().append("info", "[LOGGING_OUT] " + mListener.getEmployee().get("username") + " / " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()) + " / " + mListener.wifiIpAddress(getActivity()));
                            loggingEvents.insertOne(document);
                            return null;
                        }
                    }.execute().get();
                } catch (InterruptedException | ExecutionException e) {
                    e.printStackTrace();
                }
                getActivity().finish();
                System.exit(0);
            }
        });
    }

    private void generateNotificationsReport() throws FileNotFoundException, DocumentException {
        String file = "PharmacyApp_Notifications_Report.pdf";
        com.itextpdf.text.Document pdfDoc = new com.itextpdf.text.Document();
        FileOutputStream fileOutputStream = new FileOutputStream(new File("/sdcard/" + file), false);
        PdfWriter.getInstance(pdfDoc, fileOutputStream);
        pdfDoc.open();
        pdfDoc.addTitle("PharmacyApp Notifications Report");
        pdfDoc.addSubject("PharmacyApp Notifications Report");
        pdfDoc.addKeywords("PharmacyApp, notifications");
        pdfDoc.addAuthor("PharmacyApp");
        pdfDoc.addCreator("PharmacyApp");
        Paragraph preface = new Paragraph();
        for (int i = 0; i < 1; i++) {
            preface.add(new Paragraph(" "));
        }
        preface.add(new Paragraph("Low Quantity Medicines", catFont));
        for (int i = 0; i < 1; i++) {
            preface.add(new Paragraph(" "));
        }
        preface.add(new Paragraph("Report generated by: PharmacyApp, " + new Date(), smallBold));
        for (int i = 0; i < 3; i++) {
            preface.add(new Paragraph(" "));
        }
        preface.add(new Paragraph("This document details medicines with availableQuantity lower than 10.", smallBold));
        for (int i = 0; i < 8; i++) {
            preface.add(new Paragraph(" "));
        }
        preface.add(new Paragraph("This document was automatically generated by app.", redFont));
        pdfDoc.add(preface);
        pdfDoc.newPage();
        Anchor anchor = new Anchor("Medicine Details", catFont);
        anchor.setName("Medicine Details");
        Chapter catPart = new Chapter(new Paragraph(anchor), 1);
        Paragraph subPara = new Paragraph("Low Quantity Medicines", subFont);
        Section subCatPart = catPart.addSection(subPara);
        subCatPart.add(new Paragraph("Table below details medicines fulfilling requirements:"));
        Paragraph paragraph = new Paragraph();
        for (int i = 0; i < 5; i++) {
            paragraph.add(new Paragraph(" "));
        }
        subCatPart.add(paragraph);
        createTable(subCatPart);
        pdfDoc.add(catPart);
        pdfDoc.close();
    }

    private void createTable(Section subCatPart) throws BadElementException {
        final PdfPTable table = new PdfPTable(3);
        PdfPCell c1 = new PdfPCell(new Phrase("Medicine Name"));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c1);
        c1 = new PdfPCell(new Phrase("Available Quantity"));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c1);
        c1 = new PdfPCell(new Phrase("Number Of Packages Sold"));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c1);
        table.setHeaderRows(1);
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    for (Document document : mListener.getMongoDatabase().getCollection("medicines").find()) {
                        if (((Integer) document.get("availableQuantity") < 10) && (!((boolean) document.get("discontinued")))) {
                            table.addCell((String) document.get("name"));
                            table.addCell(String.valueOf(document.get("availableQuantity")));
                            table.addCell(String.valueOf(document.get("numberOfPackagesSold")));
                        }
                    }
                    return null;
                }
            }.execute().get();
            subCatPart.add(table);
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

}
