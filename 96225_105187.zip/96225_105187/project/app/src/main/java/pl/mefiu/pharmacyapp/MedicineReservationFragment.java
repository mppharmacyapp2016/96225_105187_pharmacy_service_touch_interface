package pl.mefiu.pharmacyapp;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Pattern;

import org.bson.Document;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import roboguice.fragment.RoboFragment;
import roboguice.inject.InjectView;

import static com.mongodb.client.model.Filters.eq;

public class MedicineReservationFragment extends RoboFragment implements Validator.ValidationListener {

    @InjectView(R.id.fragment_medicine_reservation_manufacturer_edit_text)
    private EditText manufacturerEditText;

    @InjectView(R.id.fragment_medicine_reservation_name_edit_text)
    private EditText nameEditText;

    @InjectView(R.id.fragment_medicine_reservation_type_edit_text)
    private EditText typeEditText;

    @InjectView(R.id.fragment_medicine_reservation_dose_edit_text)
    private EditText doseEditText;

    @NotEmpty
    @Pattern(regex = "[0-9]+")
    @InjectView(R.id.fragment_medicine_reservation_quantity_edit_text)
    private EditText quantityEditText;

    @InjectView(R.id.fragment_medicine_reservation_previous_button)
    private Button previousButton;

    @InjectView(R.id.fragment_medicine_reservation_next_button)
    private Button nextButton;

    @InjectView(R.id.fragment_medicine_reservation_reserve_button)
    private Button reserveButton;

    private OnFragmentInteractionListener mListener;

    private List<Document> documents = new ArrayList<>();

    private int currentDocument;

    private Validator validator;

    public MedicineReservationFragment() {
    }

    public static MedicineReservationFragment newInstance(String param1, String param2) {
        MedicineReservationFragment fragment = new MedicineReservationFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        validator = new Validator(this);
        validator.setValidationListener(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_medicine_reservation, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        reserveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validator.validate();
            }
        });
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentDocument < (documents.size() - 1)) {
                    currentDocument++;
                    updateMedicineView();
                }
            }
        });
        previousButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentDocument > 0) {
                    currentDocument--;
                    updateMedicineView();
                }
            }
        });
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    for (Document document : mListener.getMongoDatabase().getCollection("medicines").find()) {
                        documents.add(document);
                    }
                    return null;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        currentDocument = 0;
        updateMedicineView();
    }

    private void updateMedicineView() {
        if (documents.size() == 0) {
            return;
        }
        manufacturerEditText.setText((String) documents.get(currentDocument).get("manufacturer"));
        nameEditText.setText((String) documents.get(currentDocument).get("name"));
        typeEditText.setText((String) documents.get(currentDocument).get("type"));
        doseEditText.setText(String.valueOf(documents.get(currentDocument).get("dose")));
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onValidationSucceeded() {
        if (documents.size() == 0) {
            return;
        }
        final Integer quantity = Integer.valueOf(quantityEditText.getText().toString());
        boolean flag = false;
        try {
            flag = new AsyncTask<Void, Void, Boolean>() {
                @Override
                protected Boolean doInBackground(Void... params) {
                    for (Document document : mListener.getMongoDatabase().getCollection("medicines").find()) {
                        String name = (String) document.get("name");
                        String _name = (String) documents.get(currentDocument).get("name");
                        if (name.equals(_name)) {
                            Integer availableQuantity = (Integer) document.get("availableQuantity");
                            Integer numberOfPackagesFrozen = (Integer) document.get("numberOfPackagesFrozen");
                            if (availableQuantity >= quantity) {
                                Integer newAvailableQuantity = availableQuantity - quantity;
                                Integer newNumberOfPackagesFrozen = numberOfPackagesFrozen + quantity;
                                final Document doc = new Document();
                                doc.append("availableQuantity", newAvailableQuantity);
                                doc.append("numberOfPackagesFrozen", newNumberOfPackagesFrozen);
                                mListener.getMongoDatabase().getCollection("medicines").updateOne(eq("_id", documents.get(currentDocument).get("_id")), new Document("$set", doc));
                                return true;
                            }
                        }
                    }
                    return false;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        if (flag) {
            getFragmentManager().popBackStack();
        } else {
            Toast.makeText(getActivity(), "Cannot reserve more packages of medicine than available", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(getActivity().getApplicationContext());
            if (view instanceof EditText) {
                ((EditText) view).setError(message);
            } else {
                Toast.makeText(getActivity().getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }
        }
    }

}
