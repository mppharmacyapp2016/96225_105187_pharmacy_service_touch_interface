package pl.mefiu.pharmacyapp;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.mongodb.client.MongoCollection;

import org.bson.Document;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import roboguice.fragment.RoboFragment;
import roboguice.inject.InjectView;

import static com.mongodb.client.model.Filters.eq;

public class DiscontinueMedicineSaleFragment extends RoboFragment {

    @InjectView(R.id.fragment_discontinue_medicine_sale_manufacturer_edit_text)
    private EditText manufacturerEditText;

    @InjectView(R.id.fragment_discontinue_medicine_sale_name_edit_text)
    private EditText nameEditText;

    @InjectView(R.id.fragment_discontinue_medicine_sale_type_edit_text)
    private EditText typeEditText;

    @InjectView(R.id.fragment_discontinue_medicine_sale_dose_edit_text)
    private EditText doseEditText;

    @InjectView(R.id.fragment_discontinue_medicine_sale_discontinued_state_edit_text)
    private EditText discontinuedStateEditText;

    @InjectView(R.id.fragment_discontinue_medicine_sale_previous_button)
    private Button previousButton;

    @InjectView(R.id.fragment_discontinue_medicine_sale_next_button)
    private Button nextButton;

    @InjectView(R.id.fragment_discontinue_medicine_sale_discontinue_switch_button)
    private Button discontinueSwitchButton;

    private OnFragmentInteractionListener mListener;

    private List<Document> documents = new ArrayList<>();

    private int currentDocument;

    public DiscontinueMedicineSaleFragment() {
    }

    public static DiscontinueMedicineSaleFragment newInstance(String param1, String param2) {
        DiscontinueMedicineSaleFragment fragment = new DiscontinueMedicineSaleFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_discontinue_medicine_sale, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        discontinueSwitchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (documents.size() == 0) {
                    return;
                }
                Boolean discontinued = (Boolean) documents.get(currentDocument).get("discontinued");
                final Document document = new Document();
                if (discontinued) {
                    document.append("discontinued", false);
                } else {
                    document.append("discontinued", true);
                }
                final MongoCollection<Document> medicines = mListener.getMongoDatabase().getCollection("medicines");
                try {
                    new AsyncTask<Void, Void, Void>() {
                        @Override
                        protected Void doInBackground(Void... params) {
                            medicines.updateOne(eq("_id", documents.get(currentDocument).get("_id")), new Document("$set", document));
                            return null;
                        }
                    }.execute().get();
                } catch (InterruptedException | ExecutionException e) {
                    e.printStackTrace();
                }
                getFragmentManager().popBackStack();
            }
        });
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentDocument < (documents.size() - 1)) {
                    currentDocument++;
                    updateMedicineView();
                }
            }
        });
        previousButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentDocument > 0) {
                    currentDocument--;
                    updateMedicineView();
                }
            }
        });
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    for (Document document : mListener.getMongoDatabase().getCollection("medicines").find()) {
                        documents.add(document);
                    }
                    return null;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        currentDocument = 0;
        updateMedicineView();
    }

    private void updateMedicineView() {
        if (documents.size() == 0) {
            return;
        }
        manufacturerEditText.setText((String) documents.get(currentDocument).get("manufacturer"));
        nameEditText.setText((String) documents.get(currentDocument).get("name"));
        typeEditText.setText((String) documents.get(currentDocument).get("type"));
        doseEditText.setText(String.valueOf(documents.get(currentDocument).get("dose")));
        discontinuedStateEditText.setText(String.valueOf(documents.get(currentDocument).get("discontinued")));
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

}
