package pl.mefiu.pharmacyapp;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.mongodb.client.MongoCollection;

import org.bson.Document;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import roboguice.fragment.RoboFragment;
import roboguice.inject.InjectView;

import static com.mongodb.client.model.Filters.eq;

public class ViewEmployeeFragment extends RoboFragment {

    @InjectView(R.id.fragment_view_employee_full_name_edit_text)
    private EditText fullNameEditText;

    @InjectView(R.id.fragment_view_employee_first_name_edit_text)
    private EditText firstNameEditText;

    @InjectView(R.id.fragment_view_employee_second_name_edit_text)
    private EditText secondNameEditText;

    @InjectView(R.id.fragment_view_employee_username_edit_text)
    private EditText usernameEditText;

    @InjectView(R.id.fragment_view_employee_password_edit_text)
    private EditText passwordEditText;

    @InjectView(R.id.fragment_view_employee_personal_identification_number_edit_text)
    private EditText personalIdentificationNumberEditText;

    @InjectView(R.id.fragment_view_employee_email_edit_text)
    private EditText emailEditText;

    @InjectView(R.id.fragment_view_employee_phone_number_edit_text)
    private EditText phoneNumberEditText;

    @InjectView(R.id.fragment_view_employee_country_edit_text)
    private EditText countryEditText;

    @InjectView(R.id.fragment_view_employee_state_edit_text)
    private EditText stateEditText;

    @InjectView(R.id.fragment_view_employee_city_edit_text)
    private EditText cityEditText;

    @InjectView(R.id.fragment_view_employee_postal_code_edit_text)
    private EditText postalCodeEditText;

    @InjectView(R.id.fragment_view_employee_street_edit_text)
    private EditText streetEditText;

    @InjectView(R.id.fragment_view_employee_home_number_edit_text)
    private EditText homeNumberEditText;

    @InjectView(R.id.fragment_view_employee_salary_edit_text)
    private EditText salaryEditText;

    @InjectView(R.id.fragment_view_employee_active_edit_text)
    private EditText activeEditText;

    @InjectView(R.id.fragment_view_employee_position_edit_text)
    private EditText positionEditText;

    @InjectView(R.id.fragment_view_employee_number_of_shopping_carts_edit_text)
    private EditText numberOfShoppingCartsEditText;

    @InjectView(R.id.fragment_view_employee_logged_in_edit_text)
    private EditText loggedInEditText;

    @InjectView(R.id.fragment_view_employee_previous_button)
    private Button previousButton;

    @InjectView(R.id.fragment_view_employee_next_button)
    private Button nextButton;

    @InjectView(R.id.fragment_view_employee_fire_employee_button)
    private Button fireButton;

    private OnFragmentInteractionListener mListener;

    private List<Document> documents = new ArrayList<>();

    private int currentDocument;

    public ViewEmployeeFragment() {
    }

    public static ViewEmployeeFragment newInstance(String param1, String param2) {
        ViewEmployeeFragment fragment = new ViewEmployeeFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_view_employee, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentDocument < (documents.size() - 1)) {
                    currentDocument++;
                    updateEmployeeView();
                }
            }
        });
        previousButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentDocument > 0) {
                    currentDocument--;
                    updateEmployeeView();
                }
            }
        });
        fireButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (documents.size() == 0) {
                    return;
                }
                Boolean active = (Boolean) documents.get(currentDocument).get("active");
                final Document document = new Document();
                if (active) {
                    document.append("active", false);
                } else {
                    document.append("active", true);
                }
                final MongoCollection<Document> employees = mListener.getMongoDatabase().getCollection("employees");
                try {
                    new AsyncTask<Void, Void, Void>() {
                        @Override
                        protected Void doInBackground(Void... params) {
                            if (documents.get(currentDocument).get("position").equals("EMPLOYEE")) {
                                employees.updateOne(eq("_id", documents.get(currentDocument).get("_id")), new Document("$set", document));
                            }
                            return null;
                        }
                    }.execute().get();
                } catch (InterruptedException | ExecutionException e) {
                    e.printStackTrace();
                }
                getFragmentManager().popBackStack();
            }
        });
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    for (Document document : mListener.getMongoDatabase().getCollection("employees").find()) {
                        documents.add(document);
                    }
                    return null;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        currentDocument = 0;
        updateEmployeeView();
    }

    private void updateEmployeeView() {
        if (documents.size() == 0) {
            return;
        }
        fullNameEditText.setText(documents.get(currentDocument).get("firstName") + " " + documents.get(currentDocument).get("secondName"));
        firstNameEditText.setText((String) documents.get(currentDocument).get("firstName"));
        secondNameEditText.setText((String) documents.get(currentDocument).get("secondName"));
        usernameEditText.setText((String) documents.get(currentDocument).get("username"));
        passwordEditText.setText((String) documents.get(currentDocument).get("password"));
        personalIdentificationNumberEditText.setText((String) documents.get(currentDocument).get("personalIdentificationNumber"));
        emailEditText.setText((String) documents.get(currentDocument).get("email"));
        phoneNumberEditText.setText((String) documents.get(currentDocument).get("phoneNumber"));
        countryEditText.setText((String) documents.get(currentDocument).get("country"));
        stateEditText.setText((String) documents.get(currentDocument).get("state"));
        cityEditText.setText((String) documents.get(currentDocument).get("city"));
        postalCodeEditText.setText((String) documents.get(currentDocument).get("postalCode"));
        streetEditText.setText((String) documents.get(currentDocument).get("street"));
        homeNumberEditText.setText((String) documents.get(currentDocument).get("homeNumber"));
        salaryEditText.setText((String) documents.get(currentDocument).get("salary"));
        activeEditText.setText(String.valueOf((boolean) documents.get(currentDocument).get("active")));
        loggedInEditText.setText(String.valueOf((boolean) documents.get(currentDocument).get("loggedIn")));
        numberOfShoppingCartsEditText.setText(String.valueOf(documents.get(currentDocument).get("numberOfShoppingCarts")));
        positionEditText.setText((String) documents.get(currentDocument).get("position"));
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

}
