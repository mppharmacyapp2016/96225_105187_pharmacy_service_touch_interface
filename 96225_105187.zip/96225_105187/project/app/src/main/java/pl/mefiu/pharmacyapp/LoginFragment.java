package pl.mefiu.pharmacyapp;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Pattern;
import com.mongodb.client.MongoCollection;

import org.bson.Document;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutionException;

import roboguice.fragment.RoboFragment;
import roboguice.inject.InjectView;

import static com.mongodb.client.model.Filters.eq;

public class LoginFragment extends RoboFragment implements Validator.ValidationListener {

    @NotEmpty
    @Pattern(regex = "[a-zA-Z0-9]+")
    @InjectView(R.id.fragment_login_username_edit_text)
    private EditText usernameEditText;

    @NotEmpty
    @Pattern(regex = "[a-zA-Z0-9]+")
    @InjectView(R.id.fragment_login_password_edit_text)
    private EditText passwordEditText;

    @InjectView(R.id.fragment_login_sign_in_button)
    private Button signInButton;

    @InjectView(R.id.fragment_login_exit_app_button)
    private Button exitAppButton;

    private OnFragmentInteractionListener mListener;

    private Validator validator;

    public LoginFragment() {
    }

    public static LoginFragment newInstance(String param1, String param2) {
        LoginFragment fragment = new LoginFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        validator = new Validator(this);
        validator.setValidationListener(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_login, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validator.validate();
            }
        });
        exitAppButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
                System.exit(0);
            }
        });
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onValidationSucceeded() {
        final String username = usernameEditText.getText().toString();
        final String password = passwordEditText.getText().toString();
        final MongoCollection<Document> employees = mListener.getMongoDatabase().getCollection("employees");
        final MongoCollection<Document> loggingEvents = mListener.getMongoDatabase().getCollection("liloev");
        Document document = null;
        try {
            document = new AsyncTask<Void, Void, Document>() {
                @Override
                protected Document doInBackground(Void... params) {
                    Document document2 = null;
                    for (Document document1 : employees.find()) {
                        String username1 = (String) document1.get("username");
                        String password1 = (String) document1.get("password");
                        if ((username1.equals(username)) && (password1.equals(password))) {
                            document2 = document1;
                        }
                    }
                    return document2;
                }
            }.execute().get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        if ((document != null) && (document.get("active").equals(true)) && (document.get("loggedIn").equals(false))) {
            try {
                new AsyncTask<Void, Void, Void>() {
                    @Override
                    protected Void doInBackground(Void... params) {
                        employees.updateOne(eq("username", username), new Document("$set", new Document("loggedIn", true)));
                        return null;
                    }
                }.execute().get();
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
            try {
                new AsyncTask<Void, Void, Void>() {
                    @Override
                    protected Void doInBackground(Void... params) {
                        Document document1 = new Document().append("info", "[LOGGING_IN] " + username + " / " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()) + " / " + mListener.wifiIpAddress(getActivity()));
                        loggingEvents.insertOne(document1);
                        return null;
                    }
                }.execute().get();
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
            mListener.loggedIn(document);
        } else {
            Toast.makeText(getActivity(), "No such user or wrong password or you are fired or you are already logged in!", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(getActivity().getApplicationContext());
            if (view instanceof EditText) {
                ((EditText) view).setError(message);
            } else {
                Toast.makeText(getActivity().getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }
        }
    }

}
